#pragma once

#include "MusicLibrary.h"
#include "UserInterface.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <list>

/**
 * @class Application
 * @brief The "Controller" - Runs the main loop and connects UI to the Library.
 */
class Application
{
private:
    // --- Main Loop Functions ---
    void handleEvents();
    void update();
    void render();

    /**
     * @brief Connects all TGUI button signals to handler functions.
     */
    void connectSignals();

    // --- Music Player Logic ---
    void playSong(const Song& song);
    void playNextInQueueOrList();

    // --- Signal Handlers (The "Glue") ---
    void onPlayPauseClicked();
    void onNextClicked();
    void onPrevClicked();

    /**
     * @brief Feature 2: Handles the "Scan Folder" button click.
     */
    void onScanFolderClicked();

    /**
     * @brief Feature 3: Handles text changing in the search box.
     */
    void onSearchQueryChanged();

    /**
     * @brief Feature 5: Handles the sort button clicks.
     */
    void onSortClicked(string criteria);

    /**
     * @brief Feature 6 & 7: Handles right-click context menu (e.g., "Add to Queue").
     */
    void onSongRightClicked(); // This would open a context menu
    void onAddToQueue();


    // --- Core Components ---
    sf::RenderWindow m_window;
    tgui::Gui m_gui;
    sf::Music m_musicPlayer;

    // --- Our MVC Components ---
    MusicLibrary    m_library;  // The Model
    UserInterface   m_ui;       // The View

    // --- Application State ---
    bool m_isPlaying;
    Song m_currentSong;

public:
    Application();
    void run();
};
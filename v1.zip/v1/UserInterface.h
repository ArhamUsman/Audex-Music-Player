#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <vector>
#include "Song.h"

/**
 * @class UserInterface
 * @brief The "View" - Manages all TGUI widgets.
 */
class UserInterface
{
private:
    tgui::Gui& m_gui; // Reference to the main GUI

    // Key Widgets
    tgui::ListView::Ptr m_songListView;
    tgui::EditBox::Ptr m_searchBox;
    tgui::Button::Ptr m_playPauseButton, m_nextButton, m_prevButton;
    tgui::Label::Ptr m_nowPlayingTitle, m_nowPlayingArtist;
    tgui::Slider::Ptr m_progressSlider;
    tgui::Button::Ptr m_scanFolder;

    // Feature 5 Buttons
    tgui::Button::Ptr m_sortByTitle, m_sortByArtist, m_sortByDuration;

    // Feature 6/7 Buttons
    tgui::Button::Ptr m_viewHistory, m_viewQueue;

public:
    /**
     * @brief Creates all widgets and sets up the layout from our blueprint.
     */
    UserInterface(tgui::Gui& gui);

    /**
     * @brief Repopulates the main song list view with a new vector of songs.
     */
    void build();

    /**
     * @brief Updates the "Now Playing" panel.
     */
    void updateSongList(const std::vector<Song>& songs);
    
    /**
     * @brief Updates the progress slider.
     */
    void updateNowPlaying(const Song& song);

    /**
     * @brief Toggles the Play/Pause button's icon.
     */
    void updateProgress(sf::Time elapsed, sf::Time duration);

    /**
     * @brief Gets the currently selected song from the list view.
     */
    void setPlayButtonState(bool isPlaying);

    std::string getSelectedSongID(); // Returns the file path as a unique ID

    // --- Widget Accessors for the Controller ---
    tgui::Button::Ptr getPlayPauseButton() const { return m_playPauseButton; }
    tgui::Button::Ptr getNextButton() const { return m_nextButton; }
    tgui::Button::Ptr getPrevButton() const { return m_prevButton; }
    tgui::ListView::Ptr getSongListView() const { return m_songListView; }
    tgui::EditBox::Ptr getSearchBox() const { return m_searchBox; }

    // Accessors for Feature 5
    tgui::Button::Ptr getSortByTitleButton() const { return m_sortByTitle; }
    tgui::Button::Ptr getSortByArtistButton() const { return m_sortByArtist; }
    tgui::Button::Ptr getSortByDurationButton() const { return m_sortByDuration; }

    // Accessors for Features 6 & 7
    tgui::Button::Ptr getViewHistoryButton() const { return m_viewHistory; }
    tgui::Button::Ptr getViewQueueButton() const { return m_viewQueue; }

    // Accessor for Feature 2
    tgui::Button::Ptr getScanFolderButton() const { return m_scanFolder; }

}; #pragma once

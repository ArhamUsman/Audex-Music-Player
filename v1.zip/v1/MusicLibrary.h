#pragma once

#include "Song.h"
#include <list>
#include <map>
#include <unordered_map>
#include <stack>
#include <queue>
#include <vector>
#include <string>
using namespace std;

class MusicLibrary
{

private:
    list<Song> songs;

    list<Song>::iterator curr_playing;
    /**
     * The "Single Source of Truth" for all song data.
     * std::list is a Doubly Linked List, as required.
     */
    unordered_map<string, list<Song>::iterator> hash_table;
     /**
     * The Hash Table for O(1) average search by title.
     * Key: Song Title (string)
     * Value: An iterator pointing to the song's node in m_masterSongList.
     */
    map<string, list<Song>::iterator> sort_tree;
     /**
     * The balanced AVL Tree for sorted artist view.
     * std::map is a Red-Black Tree, which meets the requirement.
     * Key: Artist Name (string)
     * Value: An iterator pointing to the song's node.
     */
    stack<list<Song>::iterator> history_stack;
    /**
     * The Stack for the "History" feature.
     */
    queue<list<Song>::iterator> play_queue;
    /**
     * The Queue for the "Play Next" feature.
     */
public:
    MusicLibrary();

    void loadFromDirectory(const string& directoryPath);
    
    list<Song> getAllSongs() const;
    
    vector<Song> searchByTitle(const string& query);    

    Song searchByName(const string& query);

    list<Song> getSortedByArtist() const;
    
    void addToPlayQueue(const string& query);

    void addToHistory(const string& query);

    stack<list<Song>::iterator> get_queued_songs();

    queue<list<Song>::iterator> get_stacked_songs();
};
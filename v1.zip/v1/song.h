#pragma once

#include <string>
using namespace std;
#include <SFML/Audio.hpp>
using namespace sf;

typedef struct{
	string title;
	string artist;
	string album;
	string filePath;
	Time duartion;
} Song;

#include "user_interface.h"

int main() {
    MusicPlayer app;
    app.run();
    return 0;
}
#include "data_structures.h"

//Main Song Class
Song::Song(const std::string& path) : filePath(path), duration(0){
    // Extract filename without extension as title
    fs::path p(path);
    title = p.stem().string();
    TagLib::FileRef f(filePath.c_str());

    if (!f.isNull() && f.tag()) {
        TagLib::Tag* tag = f.tag();
        artist = tag->artist().to8Bit(true);
        album = tag->album().to8Bit(true);
        if (f.audioProperties()) {
            duration = f.audioProperties()->lengthInSeconds();
        }
    }
    // Random color for artwork
    color = tgui::Color(rand() % 200 + 55, rand() % 200 + 55, rand() % 200 + 55);
}

//Stack for playback history
Stack::Stack() {
    topp = -1; //empty stack
}

void Stack::push(Song* a) {
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i] == a) {
            arr.erase(arr.begin() + i);
            i--;
        }
    }
    arr.push_back(a);
    topp = arr.size()-1;
}

void Stack::operator=(Stack& other) {
    arr = other.arr;
    topp = other.topp;
}

bool Stack::empty(){
    return (topp == -1);
}

Song* Stack::top() {
    if (topp == -1) return nullptr;
    return arr[topp];
}

void Stack::pop() {
    if (topp == -1) return;
    topp--;
    arr.pop_back();
}

//Queue for play next
Queue::Queue() {
    tail = -1;
}

bool Queue::empty() {
    return tail == -1;
}

Song* Queue::front() {
    if (empty()) return nullptr;
    return arr[0];
}

void Queue::pop() {
    if (empty()) return;
    arr.erase(arr.begin());
    tail--;
}

void Queue::push(Song* a) {
    remove(a);
    arr.push_back(a);
    tail = arr.size() - 1;
}

void Queue::operator=(Queue& other) {
    arr = other.arr;
    tail = other.tail;
}

bool Queue::is_in_queue(Song* other) {
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i]->title == other->title) return true;
    }
    return false;
}

void Queue::clear() {
    arr.clear();
    tail = -1;
}

void Queue::remove(Song* a) {
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i] == a) {
            arr.erase(arr.begin() + i);
            tail--;
            i--;
        }
    }
}
//Doubly Linked List Node
DLLNode::DLLNode(Song* s) : song(s), prev(nullptr), next(nullptr) {}

//Linked List Class
MusicLibrary::MusicLibrary() : head(nullptr), tail(nullptr), current(nullptr), size(0) {}

MusicLibrary::~MusicLibrary() {
    DLLNode* temp = head;
    while (temp) {
        DLLNode* next = temp->next;
        delete temp->song;
        delete temp;
        temp = next;
    }
}

void MusicLibrary::addSong(Song* song) {
    DLLNode* newNode = new DLLNode(song);
    if (!head) {
        head = tail = current = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    size++;
}

DLLNode* MusicLibrary::getHead() {
    return head;
}

DLLNode* MusicLibrary::getCurrent() {
    return current;
}

int MusicLibrary::getSize() {
    return size;
}

void MusicLibrary::clear() {
    DLLNode* temp = head;
    while (temp != tail) {
        head = temp->next;
        delete temp;
        temp = head;
    }
    if (temp != nullptr) delete temp;
    head = nullptr;
    tail = nullptr;
}

Song* MusicLibrary::next() {
    if (current && current->next) {
        current = current->next;
    }
    else current = head;
    return current->song;
}

Song* MusicLibrary::previous() {
    if (current && current->prev) {
        current = current->prev;
    }
    else current = tail;
    return current->song;
}

void MusicLibrary::setCurrent(DLLNode* node) {
    current = node;
}

std::vector<Song*> MusicLibrary::getAllSongs() {
    std::vector<Song*> songs;
    DLLNode* temp = head;
    while (temp) {
        songs.push_back(temp->song);
        temp = temp->next;
    }
    return songs;
}

//AVL Node
AVLNode::AVLNode(Song* s) : song(s), left(nullptr), right(nullptr), height(1) {}

//AVL Tree
int AVLTree::height(AVLNode* node) {
    return node ? node->height : 0;
}

int AVLTree::getBalance(AVLNode* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

AVLNode* AVLTree::rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    return x;
}

AVLNode* AVLTree::leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    return y;
}

AVLNode* AVLTree::insert(AVLNode* node, Song* song) {
    if (!node) return new AVLNode(song);

    if (song->artist < node->song->artist)
        node->left = insert(node->left, song);
    else
        node->right = insert(node->right, song);

    node->height = 1 + std::max(height(node->left), height(node->right));
    int balance = getBalance(node);

    // Left Left
    if (balance > 1 && song->artist < node->left->song->artist)
        return rightRotate(node);

    // Right Right
    if (balance < -1 && song->artist > node->right->song->artist)
        return leftRotate(node);

    // Left Right
    if (balance > 1 && song->artist > node->left->song->artist) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Right Left
    if (balance < -1 && song->artist < node->right->song->artist) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

void AVLTree::inorderTraversal(AVLNode* node, std::vector<Song*>& songs) {
    if (!node) return;
    inorderTraversal(node->left, songs);
    songs.push_back(node->song);
    inorderTraversal(node->right, songs);
}

AVLTree::AVLTree() : root(nullptr) {}

void AVLTree::insert(Song* song) {
    root = insert(root, song);
}

std::vector<Song*> AVLTree::getSortedByArtist() {
    std::vector<Song*> songs;
    inorderTraversal(root, songs);
    return songs;
}

void AVLTree::self_destroy(AVLNode*& r) {
    if (r->left) self_destroy(r->left);
    if (r->right) self_destroy(r->right);
    delete r;
    r = nullptr;
}

void AVLTree::clear() {
    self_destroy(root);
}
#include "data_structures.h"

Song::Song(const std::string& path) : filePath(path), duration(0) {
    // Extract filename without extension as title
    fs::path p(path);
    title = p.stem().string();
    TagLib::FileRef f(filePath.c_str());

    if (!f.isNull() && f.tag()) {
        TagLib::Tag* tag = f.tag();
        artist = tag->artist().to8Bit(true);
        album = tag->album().to8Bit(true);
    }
    // Random color for artwork
    color = tgui::Color(rand() % 200 + 55, rand() % 200 + 55, rand() % 200 + 55);
}

DLLNode::DLLNode(Song* s) : song(s), prev(nullptr), next(nullptr) {}

MusicLibrary::MusicLibrary() : head(nullptr), tail(nullptr), current(nullptr), size(0) {}

MusicLibrary::~MusicLibrary() {
    DLLNode* temp = head;
    while (temp) {
        DLLNode* next = temp->next;
        delete temp->song;
        delete temp;
        temp = next;
    }
}

void MusicLibrary::addSong(Song* song) {
    DLLNode* newNode = new DLLNode(song);
    if (!head) {
        head = tail = current = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    size++;
}

DLLNode* MusicLibrary::getHead() {
    return head;
}

DLLNode* MusicLibrary::getCurrent() {
    return current;
}

int MusicLibrary::getSize() {
    return size;
}

Song* MusicLibrary::next() {
    if (current && current->next) {
        current = current->next;
        return current->song;
    }
    return nullptr;
}

Song* MusicLibrary::previous() {
    if (current && current->prev) {
        current = current->prev;
        return current->song;
    }
    return nullptr;
}

void MusicLibrary::setCurrent(DLLNode* node) {
    current = node;
}

std::vector<Song*> MusicLibrary::getAllSongs() {
    std::vector<Song*> songs;
    DLLNode* temp = head;
    while (temp) {
        songs.push_back(temp->song);
        temp = temp->next;
    }
    return songs;
}

AVLNode::AVLNode(Song* s) : song(s), left(nullptr), right(nullptr), height(1) {}

int AVLTree::height(AVLNode* node) {
    return node ? node->height : 0;
}

int AVLTree::getBalance(AVLNode* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

AVLNode* AVLTree::rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    return x;
}

AVLNode* AVLTree::leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    return y;
}


AVLNode* AVLTree::insert(AVLNode* node, Song* song) {
    if (!node) return new AVLNode(song);

    if (song->artist < node->song->artist)
        node->left = insert(node->left, song);
    else
        node->right = insert(node->right, song);

    node->height = 1 + std::max(height(node->left), height(node->right));
    int balance = getBalance(node);

    // Left Left
    if (balance > 1 && song->artist < node->left->song->artist)
        return rightRotate(node);

    // Right Right
    if (balance < -1 && song->artist > node->right->song->artist)
        return leftRotate(node);

    // Left Right
    if (balance > 1 && song->artist > node->left->song->artist) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Right Left
    if (balance < -1 && song->artist < node->right->song->artist) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

void AVLTree::inorderTraversal(AVLNode* node, std::vector<Song*>& songs) {
    if (!node) return;
    inorderTraversal(node->left, songs);
    songs.push_back(node->song);
    inorderTraversal(node->right, songs);
}

AVLTree::AVLTree() : root(nullptr) {}

void AVLTree::insert(Song* song) {
    root = insert(root, song);
}


std::vector<Song*> AVLTree::getSortedByArtist() {
    std::vector<Song*> songs;
    inorderTraversal(root, songs);
    return songs;
}
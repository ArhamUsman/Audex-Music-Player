#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <taglib/tag.h>
#include <taglib/fileref.h>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <unordered_map>
#include <stack>
#include <queue>
#include <algorithm>
#include "pfd.h"

namespace fs = std::filesystem;

// Song structure
struct Song {
    std::string filePath;
    std::string title;
    std::string artist;
    std::string album;
    int duration;
    tgui::Color color;
    Song() = default;
    Song(const std::string& path);
};

// 1. Doubly Linked List Node
struct DLLNode {
    Song* song;
    DLLNode* prev;
    DLLNode* next;

    DLLNode(Song* s);
};


// Doubly Linked List for Music Library
class MusicLibrary {
private:
    DLLNode* head;
    DLLNode* tail;
    DLLNode* current;
    int size;

public:
    MusicLibrary();

    ~MusicLibrary();

    void addSong(Song* song);

    DLLNode* getHead();

    DLLNode* getCurrent();

    int getSize();

    Song* next();

    Song* previous();

    void setCurrent(DLLNode* node);

    std::vector<Song*> getAllSongs();
};

// 4. AVL Tree Node for sorted view
struct AVLNode {
    Song* song;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(Song* s);
};

class AVLTree {
private:
    AVLNode* root;

    int height(AVLNode* node);

    int getBalance(AVLNode* node);

    AVLNode* rightRotate(AVLNode* y);

    AVLNode* leftRotate(AVLNode* x);

    AVLNode* insert(AVLNode* node, Song* song);

    void inorderTraversal(AVLNode* node, std::vector<Song*>& songs);

public:
    AVLTree();

    void insert(Song* song);

    std::vector<Song*> getSortedByArtist();
};

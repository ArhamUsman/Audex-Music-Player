#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <unordered_map>
#include <stack>
#include <queue>
#include <algorithm>
#include "pfd.h"
#include "data_structures.h"
#include "user_interface.h"
namespace fs = std::filesystem;


int main() {
    SpotifyApp app;
    app.run();
    return 0;
}
#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <unordered_map>
#include <stack>
#include <queue>
#include <algorithm>
#include "pfd.h"
#include "data_structures.h"
using namespace std;

// Main Application
class SpotifyApp {
private:
    sf::RenderWindow window;
    tgui::Gui gui;
    MusicLibrary library;
    AVLTree avlTree;
    std::unordered_map<std::string, DLLNode*> hashTable; // 3. Hash table for search
    std::stack<Song*> playbackHistory; // 6. Stack for history
    std::queue<Song*> playQueue; // 7. Queue for play next

    int currentSongIndex;
    bool isPlaying;
    float currentTime;
    tgui::Slider::Ptr progressSlider;
    tgui::Label::Ptr timeLabel;
    tgui::Button::Ptr playPauseBtn;
    tgui::Label::Ptr currentSongTitle;
    tgui::Label::Ptr currentSongArtist;
    tgui::Panel::Ptr currentArtwork;
    tgui::ListBox::Ptr songListBox;
    tgui::EditBox::Ptr searchBox;
    sf::Clock clock;
    sf::Music music;

public:
    SpotifyApp();

    // 2. Recursive folder scanning
    void scanFolderRecursive(const std::string& path);

    // 3. Search using hash table
    void searchSong(const std::string& query);

    // 5. Sorting algorithms
    void quickSort(std::vector<Song*>& songs, size_t low, size_t high, bool (*compare)(Song*, Song*));

    void sortLibrary(const std::string& sortBy);

    void setupUI();

    void createSidebar();

    tgui::Button::Ptr createNavButton(const std::string& text, float y);

    void createMainContent();

    void createPlayerBar();

    void importFolder();

    void updateSongList(const std::vector<Song*>& songs);

    void playSongByPointer(Song* song);

    void togglePlayPause();

    void nextSong();

    void previousSong();

    void addCurrentToQueue();

    void showHistory();

    void showQueue();

    void run();
};

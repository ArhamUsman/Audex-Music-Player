#include "user_interface.h"

MusicPlayer::MusicPlayer() : window(sf::VideoMode({ 750, 565 }), "Audex"), gui(window),
currentSongIndex(0), isPlaying(false), currentTime(0) {
    window.setFramerateLimit(60);
    setupUI();
    importFolder();
    auto songs = library.getAllSongs();
    playSongByPointer(songs[0]);
    togglePlayPause();
}

void MusicPlayer::scanFolderRecursive(const std::string& path) {
    try {
        for (const auto& entry : fs::recursive_directory_iterator(path)) {
            if (entry.is_regular_file()) {
                std::string ext = entry.path().extension().string();
                std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);

                if (ext == ".mp3") {
                    Song* song = new Song(entry.path().string());
                    library.addSong(song);
                    avlTree.insert(song);

                    // Add to hash table for quick search
                    std::string lowerTitle = song->title;
                    std::transform(lowerTitle.begin(), lowerTitle.end(), lowerTitle.begin(), ::tolower);

                    DLLNode* temp = library.getHead();
                    while (temp && temp->song != song) {
                        temp = temp->next;
                    }
                    if (temp) {
                        hashTable[lowerTitle] = temp;
                    }
                }
            }
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Error scanning folder: " << e.what() << std::endl;
    }
}

void MusicPlayer::searchSong(const std::string& query) {
    std::string lowerQuery = query;
    std::transform(lowerQuery.begin(), lowerQuery.end(), lowerQuery.begin(), ::tolower);

    songListBox->removeAllItems();

    if (lowerQuery.empty()) {
        updateSongList(library.getAllSongs());
        return;
    }

    std::vector<Song*> results;
    for (const auto& pair : hashTable) {
        if (pair.first.find(lowerQuery) != std::string::npos) {
            results.push_back(pair.second->song);
        }
    }

    updateSongList(results);
}

void MusicPlayer::quickSort(std::vector<Song*>& songs, size_t low, size_t high, bool (*compare)(Song*, Song*)) {
    if (low < high) {
        Song* pivot = songs[high];
        size_t i = low;
        bool found = false;

        for (size_t j = low; j < high; j++) {
            if (compare(songs[j], pivot)) {
                if (!found) found = true;
                std::swap(songs[i], songs[j]);
                i++;
            }
        }
        std::swap(songs[i], songs[high]);
        size_t pi = i;

        if (pi > 0) quickSort(songs, low, pi - 1, compare);
        quickSort(songs, pi + 1, high, compare);
    }
}

void MusicPlayer::sortLibrary(const std::string& sortBy) {
    std::vector<Song*> songs = library.getAllSongs();

    if (songs.empty()) return;

    if (sortBy == "Title") {
        quickSort(songs, 0, songs.size() - 1,
            [](Song* a, Song* b) { return a->title < b->title; });
    }
    else if (sortBy == "Artist (AVL)") {
        songs = avlTree.getSortedByArtist();
    }
    else if (sortBy == "Album") {
        quickSort(songs, 0, songs.size() - 1,
            [](Song* a, Song* b) { return a->album < b->album; });
    }

    updateSongList(songs);
    update_ds(songs);
}

void MusicPlayer::update_ds(std::vector<Song*> songs) {
    hashTable.clear();
    playQueue.clear();
    avlTree.clear();
    library.clear();
    for (int i = 0; i < songs.size(); i++) {
        Song* song = songs[i];
        library.addSong(song);
        avlTree.insert(song);

        // Add to hash table for quick search
        std::string lowerTitle = song->title;
        std::transform(lowerTitle.begin(), lowerTitle.end(), lowerTitle.begin(), ::tolower);

        DLLNode* temp = library.getHead();
        while (temp && temp->song != song) {
            temp = temp->next;
        }
        if (temp) {
            hashTable[lowerTitle] = temp;
        }
    }
    playSongByPointer(library.getHead()->song);
}

void MusicPlayer::setupUI() {
    auto mainPanel = tgui::Panel::create();
    mainPanel->setSize("100%", "100%");
    mainPanel->getRenderer()->setBackgroundColor(tgui::Color(18, 18, 18));
    gui.add(mainPanel);

    createSidebar();
    createMainContent();
    createPlayerBar();
}

void MusicPlayer::createSidebar() {
    auto sidebar = tgui::Panel::create();
    sidebar->setSize(240, "100%");
    sidebar->setPosition(0, 0);
    sidebar->getRenderer()->setBackgroundColor(tgui::Color(0, 0, 0));
    gui.add(sidebar);

    auto logo = tgui::Label::create("Audex");
    logo->setPosition(70, 20);
    logo->setTextSize(30);
    logo->getRenderer()->setTextColor(tgui::Color(135, 206, 250));
    sidebar->add(logo);

    // Search bar
    searchBox = tgui::EditBox::create();
    searchBox->setSize(220, 35);
    searchBox->setPosition(10, 100);
    searchBox->setDefaultText("Search...");
    searchBox->setTextSize(16);
    searchBox->getRenderer()->setTextColor(tgui::Color::White);
    searchBox->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    searchBox->getRenderer()->setBorderColor(tgui::Color(70, 70, 70));
    searchBox->getRenderer()->setDefaultTextColor(tgui::Color(160, 160, 160));
    searchBox->getRenderer()->setBackgroundColorHover(tgui::Color(70, 70, 70));
    searchBox->onTextChange([this](const tgui::String& text) {
        searchSong(text.toStdString());
        });
    sidebar->add(searchBox);

    // Sort dropdown
    auto sortDropdown = tgui::ComboBox::create();
    sortDropdown->setPosition(10, 350);
    sortDropdown->setSize(220, 35);
    sortDropdown->addItem("Sort by Title");
    sortDropdown->addItem("Sort by Artist (AVL)");
    sortDropdown->addItem("Sort by Album");
    sortDropdown->setSelectedItem("Sort by Title");
    sortDropdown->onItemSelect([this](const tgui::String& item) {
        if (item == "Sort by Title") sortLibrary("Title");
        else if (item == "Sort by Artist (AVL)") sortLibrary("Artist (AVL)");
        else if (item == "Sort by Album") sortLibrary("Album");
        });
    sidebar->add(sortDropdown);

    auto libraryBtn = createNavButton("Import Folder", 400);
    libraryBtn->onPress([this]() { importFolder(); });
    sidebar->add(libraryBtn);

    auto historyBtn = createNavButton("History (Stack)", 450);
    historyBtn->onPress([this]() { showHistory(); });
    sidebar->add(historyBtn);

    auto queueBtn = createNavButton("Play Queue", 500);
    queueBtn->onPress([this]() { showQueue(); });
    sidebar->add(queueBtn);

    // Song list
    songListBox = tgui::ListBox::create();
    songListBox->setPosition(10, 150);
    songListBox->setSize(218, 180);
    songListBox->setItemHeight(50);
    songListBox->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    songListBox->getRenderer()->setTextColor(tgui::Color::White);
    songListBox->onItemSelect([this](int index) {
        if (index >= 0) {
            auto songs = library.getAllSongs();
            if (index < songs.size()) {
                playSongByPointer(songs[index]);
            }
        }
        });
    sidebar->add(songListBox);
}

tgui::Button::Ptr MusicPlayer::createNavButton(const std::string& text, float y) {
    auto btn = tgui::Button::create(text);
    btn->setPosition(10, y);
    btn->setSize(220, 40);
    btn->setTextSize(14);
    btn->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    btn->getRenderer()->setBackgroundColorHover(tgui::Color(50, 50, 50));
    btn->getRenderer()->setTextColor(tgui::Color::White);
    btn->getRenderer()->setBorderColor(tgui::Color::Transparent);
    return btn;
}

void MusicPlayer::createMainContent() {
    auto mainContent = tgui::Panel::create();
    mainContent->setSize(510, 460);
    mainContent->setPosition(240, 0);
    mainContent->getRenderer()->setBackgroundColor(tgui::Color(10, 10, 10));
    gui.add(mainContent);

    auto header = tgui::Label::create("NOW PLAYING");
    header->setPosition(140, 30);
    header->setTextSize(32);
    header->getRenderer()->setTextColor(tgui::Color::White);
    mainContent->add(header);

    // Current song card
    currentArtwork = tgui::Panel::create();
    currentArtwork->setSize(250, 300);
    currentArtwork->setPosition(134, 85);
    currentArtwork->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    currentArtwork->getRenderer()->setRoundedBorderRadius(5);
    mainContent->add(currentArtwork);

    auto artwork = tgui::Panel::create();
    artwork->setSize(230, 200);
    artwork->setPosition(10, 10);
    artwork->getRenderer()->setBackgroundColor(tgui::Color(100, 100, 100));
    artwork->getRenderer()->setRoundedBorderRadius(5);
    // 1. Load the textures using RELATIVE PATHS
// This loop looks for assets/frame1.png, assets/frame2.png, etc.
    m_animTextures.clear();
    for (int i = 1; i <= 6; i++) {
        // "assets/" makes it dynamic/portable
        m_animTextures.push_back(tgui::Texture("assets/frame" + std::to_string(i) + ".jpg"));
    }

    // 2. Create the Picture Widget
    if (!m_animTextures.empty()) {
        // Initialize with first frame
        m_animPicture = tgui::Picture::create(m_animTextures[0]);

        // Make it fill the artwork panel
        m_animPicture->setSize("100%", "100%");

        // Add the Picture INTO the Artwork Panel
        artwork->add(m_animPicture);
    }

    // Add the artwork panel to the parent container
    currentArtwork->add(artwork);

    currentSongTitle = tgui::Label::create("No Song");
    currentSongTitle->setPosition(10, 225);
    currentSongTitle->setTextSize(14);
    currentSongTitle->getRenderer()->setTextColor(tgui::Color::White);
    currentArtwork->add(currentSongTitle);

    currentSongArtist = tgui::Label::create("Select a song");
    currentSongArtist->setPosition(10, 250);
    currentSongArtist->setTextSize(12);
    currentSongArtist->getRenderer()->setTextColor(tgui::Color(160, 160, 160));
    currentArtwork->add(currentSongArtist);

    queueCheck->setPosition(30, 420);
    queueCheck->setSize(25, 25);
    queueCheck->setText("Add to Queue");
    queueCheck->setTextSize(16);

    // --- UNCHECKED STATE ---
    queueCheck->getRenderer()->setBackgroundColor(tgui::Color::Transparent);
    queueCheck->getRenderer()->setBorderColor(tgui::Color::White);
    queueCheck->getRenderer()->setTextColor(tgui::Color::White);

    // --- CHECKED STATE (Changed to Blue) ---
    // Using Dodger Blue (30, 144, 255) for the box
    queueCheck->getRenderer()->setBackgroundColorChecked(tgui::Color(30, 144, 255));
    queueCheck->getRenderer()->setBorderColorChecked(tgui::Color(30, 144, 255));
    queueCheck->getRenderer()->setCheckColor(tgui::Color::White);

    // --- HOVER STATE ---
    // White border for the box
    queueCheck->getRenderer()->setBorderColorHover(tgui::Color::White);

    // FIX: Text changes to Light Sky Blue on hover instead of Black
    queueCheck->getRenderer()->setTextColorHover(tgui::Color(135, 206, 250));

    // LOGIC
    queueCheck->onChange([this](bool checked) {
        if (checked) addCurrentToQueue();
        else removeCurrentFromQueue();
        });

    mainContent->add(queueCheck);
}

void MusicPlayer::updateAnimation(sf::Time dt)
{
    // Safety check
    if (m_animTextures.empty() || !m_animPicture) return;

    // Add elapsed time
    m_animTimer += dt;

    // 20 FPS = 1 second / 20 = 0.05 seconds per frame
    if (m_animTimer.asSeconds() >= 400.0f) {

        // Remove 0.05s from the timer
        m_animTimer -= sf::seconds(400.0f);

        // Move to next frame
        m_currentFrame++;

        // Loop back to start if we reach the end
        if (m_currentFrame >= m_animTextures.size()) {
            m_currentFrame = 0;
        }

        // Apply the new texture
        m_animPicture->getRenderer()->setTexture(m_animTextures[m_currentFrame]);
    }
}

void MusicPlayer::update_queue(Song*& s) {
    queueCheck->setChecked(playQueue.is_in_queue(s));
}

void MusicPlayer::removeCurrentFromQueue() {
    playQueue.remove(library.getCurrent()->song);
}

void MusicPlayer::createPlayerBar() {
    auto playerBar = tgui::Panel::create();
    playerBar->setSize(510, 100);
    playerBar->setPosition(240, 460);
    playerBar->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    gui.add(playerBar);

    auto prevBtn = tgui::Button::create("Prev");
    prevBtn->setSize(50, 40);
    prevBtn->setPosition(150, 15);
    prevBtn->setTextSize(14);
    prevBtn->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    prevBtn->getRenderer()->setBackgroundColorHover(tgui::Color(60, 60, 60));
    prevBtn->getRenderer()->setTextColor(tgui::Color::White);
    prevBtn->onPress([this]() { previousSong(); });
    playerBar->add(prevBtn);

    playPauseBtn = tgui::Button::create("Play");
    playPauseBtn->setSize(60, 50);
    playPauseBtn->setPosition(230, 10);
    playPauseBtn->setTextSize(16);
    playPauseBtn->getRenderer()->setBackgroundColor(tgui::Color::White);
    playPauseBtn->getRenderer()->setTextColor(tgui::Color::Black);
    playPauseBtn->getRenderer()->setRoundedBorderRadius(5);
    playPauseBtn->onPress([this]() { togglePlayPause(); });
    playerBar->add(playPauseBtn);

    auto nextBtn = tgui::Button::create("Next");
    nextBtn->setSize(50, 40);
    nextBtn->setPosition(320, 15);
    nextBtn->setTextSize(14);
    nextBtn->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    nextBtn->getRenderer()->setBackgroundColorHover(tgui::Color(60, 60, 60));
    nextBtn->getRenderer()->setTextColor(tgui::Color::White);
    nextBtn->onPress([this]() { nextSong(); });
    playerBar->add(nextBtn);

    progressSlider = tgui::Slider::create();
    progressSlider->setSize(400, 5);
    progressSlider->setPosition(50, 70);
    progressSlider->setMinimum(0);
    progressSlider->setMaximum(100);
    progressSlider->setValue(0);

    progressSlider->onValueChange([this](float newValue) {
        // 1. Get the current actual time of the music
        float currentActualTime = music.getPlayingOffset().asSeconds();

        // 2. Calculate the difference
        // std::abs requires <cmath>
        float diff = std::abs(newValue - currentActualTime);

        // 3. Threshold Check:
        // If the difference is greater than 0.5 seconds, it means the USER dragged it.
        // (Normal playback only updates by small fractions of a second per frame)
        if (diff > 0.5f) {
            music.setPlayingOffset(sf::seconds(newValue));
        }
        });

    playerBar->add(progressSlider);

    timeLabel = tgui::Label::create("0:00 / 0:00");
    timeLabel->setPosition(230, 83);
    timeLabel->setTextSize(11);
    timeLabel->getRenderer()->setTextColor(tgui::Color(160, 160, 160));
    playerBar->add(timeLabel);
}

void MusicPlayer::importFolder() {
    auto selection = pfd::select_folder("Select Music Folder").result();
    if (!selection.empty()) {
        scanFolderRecursive(selection);
        updateSongList(library.getAllSongs());
    }
}

void MusicPlayer::updateSongList(const std::vector<Song*>& songs) {
    songListBox->removeAllItems();
    for (const auto& song : songs) {
        songListBox->addItem(song->title + " - " + song->artist);
    }
}

void MusicPlayer::select_song_by_index(int index) {
    if (index < 0 || index >= songListBox->getItemCount()) return;
    songListBox->setSelectedItemByIndex(index);
}

void MusicPlayer::playSongByPointer(Song* song) {
    if (library.getCurrent()) {
        playbackHistory.push(library.getCurrent()->song);
    }
    int index = 0;
    DLLNode* temp = library.getHead();
    while (temp && temp->song->title != song->title) {
        index++;
        temp = temp->next;
    }

    if (temp) {
        library.setCurrent(temp);
        update_queue(temp->song);
        currentSongTitle->setText(song->title);
        currentSongArtist->setText(song->artist);

        if (music.openFromFile(song->filePath)) {
            music.play();
            isPlaying = true;
            playPauseBtn->setText("Pause");
            progressSlider->setMaximum(music.getDuration().asSeconds());
        }
        select_song_by_index(index);
    }
}

void MusicPlayer::togglePlayPause() {

    if (isPlaying) {
        music.pause();
        isPlaying = false;
        playPauseBtn->setText("Play");
    }
    else {
        music.play();
        isPlaying = true;
        playPauseBtn->setText("Pause");
    }
}

void MusicPlayer::nextSong() {
    if (!playQueue.empty()) {
        Song* nextSong = playQueue.front();
        playQueue.pop();
        playSongByPointer(nextSong);
    }
    else {
        Song* next = library.next();
        if (next) {
            playSongByPointer(next);
        }
    }
}

void MusicPlayer::previousSong() {
    Song* prev = library.previous();
    if (prev) {
        playSongByPointer(prev);
    }
}

void MusicPlayer::addCurrentToQueue() {
    if (library.getCurrent()) {
        playQueue.push(library.getCurrent()->song);
    }
}

void MusicPlayer::showHistory() {
    // Display history in a message box
    std::string msg = "Playback History:\n";
    Stack tempStack;
    tempStack = playbackHistory;
    int count = 0;
    while (!tempStack.empty() && count < 10) {
        msg += tempStack.top()->title + "\n";
        tempStack.pop();
        count++;
    }
    pfd::message("History", msg, pfd::choice::ok);
}

void MusicPlayer::showQueue() {
    std::string msg = "Play Queue:\n";
    Queue tempQueue;
    tempQueue = playQueue;
    while (!tempQueue.empty()) {
        msg += tempQueue.front()->title + "\n";
        tempQueue.pop();
    }
    pfd::message("Queue", msg.empty() ? "Queue is empty" : msg, pfd::choice::ok);
}

void MusicPlayer::run() {
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();
            gui.handleEvent(*event);
        }

        if (isPlaying && music.getStatus() == sf::SoundSource::Status::Playing) {
            progressSlider->setValue(music.getPlayingOffset().asSeconds());

            int current = static_cast<int>(music.getPlayingOffset().asSeconds());
            int total = static_cast<int>(music.getDuration().asSeconds());
            std::stringstream ss;
            ss << (current / 60) << ":" << std::setw(2) << std::setfill('0') << (current % 60)
                << " / " << (total / 60) << ":" << std::setw(2) << std::setfill('0') << (total % 60);
            timeLabel->setText(ss.str());

            sf::Time dt = m_clock.getElapsedTime(); // Or however you track delta time

            // Call the UI function
            updateAnimation(dt);
        }

        if (music.getStatus() == sf::SoundSource::Status::Stopped && isPlaying) {
            nextSong();
        }

        window.clear();
        gui.draw();
        window.display();
    }
}
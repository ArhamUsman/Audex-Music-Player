#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <unordered_map>
#include <algorithm>
#include "pfd.h"
#include "data_structures.h"
using namespace std;

// Main Application
class MusicPlayer {
private:
    sf::RenderWindow window;
    tgui::Gui gui;
    MusicLibrary library;
    AVLTree avlTree;
    std::unordered_map<std::string, DLLNode*> hashTable; // 3. Hash table for search
    Stack playbackHistory; // 6. Stack for history
    Queue playQueue; // 7. Queue for play next

    int currentSongIndex;
    bool isPlaying;
    float currentTime;
    tgui::Slider::Ptr progressSlider;
    tgui::Label::Ptr timeLabel;
    tgui::Button::Ptr playPauseBtn;
    tgui::Label::Ptr currentSongTitle;
    tgui::Label::Ptr currentSongArtist;
    tgui::Panel::Ptr currentArtwork;
    tgui::ListBox::Ptr songListBox;
    tgui::EditBox::Ptr searchBox;
    sf::Clock clock;
    sf::Music music;

public:
    MusicPlayer();

    // 2. Recursive folder scanning
    void scanFolderRecursive(const std::string& path);

    // 3. Search using hash table
    void searchSong(const std::string& query);

    // 5. Sorting algorithms
    void quickSort(std::vector<Song*>& songs, size_t low, size_t high, bool (*compare)(Song*, Song*));
    
    void sortLibrary(const std::string& sortBy);

    void update_ds(std::vector<Song*> songs) {
        hashTable.clear();
        avlTree.clear();
        library.clear();
        for (int i = 0; i < songs.size(); i++) {
            Song* song = songs[i];
            library.addSong(song);
            avlTree.insert(song);

            // Add to hash table for quick search
            std::string lowerTitle = song->title;
            std::transform(lowerTitle.begin(), lowerTitle.end(), lowerTitle.begin(), ::tolower);

            DLLNode* temp = library.getHead();
            while (temp && temp->song != song) {
                temp = temp->next;
            }
            if (temp) {
                hashTable[lowerTitle] = temp;
            }
        }
        playSongByPointer(library.getHead()->song);
    }

    void setupUI();

    void createSidebar();

    tgui::Button::Ptr createNavButton(const std::string& text, float y);

    void createMainContent();

    void createPlayerBar();

    void importFolder();

    void updateSongList(const std::vector<Song*>& songs);

    void select_song_by_index(int index);

    void playSongByPointer(Song* song);
    
    void removeCurrentFromQueue();

    void togglePlayPause();

    void nextSong();

    void previousSong();

    void addCurrentToQueue();

    void showHistory();

    void showQueue();

    void run();
};

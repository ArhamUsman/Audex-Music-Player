#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <taglib/tag.h>
#include <taglib/fileref.h>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <filesystem>
#include <algorithm>
#include <cctype>
#include "pfd.h"

namespace fs = std::filesystem;

// Song structure
struct Song {
    std::string filePath;
    std::string title;
    std::string artist;
    std::string album;
    int duration;
    tgui::Color color;
    Song() = default;
    Song(const std::string& path);
};

// Stack for playback history
class Stack {
    std::vector<Song*> arr; size_t topp;
public:
    Stack();
    void push(Song* a);
    void operator=(Stack& other);
    bool empty();
    Song* top();
    void pop();
};

// Queue for play next
class Queue {
    std::vector<Song*> arr; size_t tail;
public:
    Queue();
    bool empty();
    Song* front();
    void pop();
    void push(Song* a);
    void operator=(Queue& other);
    void remove(Song* a);
    bool is_in_queue(Song* other);
    void clear();
};

// Doubly Linked List Node
struct DLLNode {
    Song* song;
    DLLNode* prev;
    DLLNode* next;

    DLLNode(Song* s);
};

// Doubly Linked List for Music Library
class MusicLibrary {
private:
    DLLNode* head;
    DLLNode* tail;
    DLLNode* current;
    size_t size;

public:
    MusicLibrary();

    ~MusicLibrary();

    void addSong(Song* song);

    DLLNode* getHead();

    DLLNode* getCurrent();

    int getSize();

    Song* next();

    Song* previous();

    void reset();

    void setCurrent(DLLNode* node);

    std::vector<Song*> getAllSongs();

    void clear();
};

bool rabin_karp(std::string title, std::string query);

// AVL Tree Node for sorted view
struct AVLNode {
    Song* song;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(Song* s);
};

// AVL Tree
class AVLTree {
private:
    AVLNode* root;

    int height(AVLNode* node);

    int getBalance(AVLNode* node);

    AVLNode* rightRotate(AVLNode* y);

    AVLNode* leftRotate(AVLNode* x);

    AVLNode* insert(AVLNode* node, Song* song);

    void inorderTraversal(AVLNode* node, std::vector<Song*>& songs);

    void self_destroy(AVLNode*& r);

    void recursive_search(std::vector<Song*>& fina, std::string s, AVLNode* curr, bool matched);
public:
    AVLTree();

    void insert(Song* song);

    void clear();

    std::vector<Song*> search(std::string s);

    std::vector<Song*> getSortedByArtist();
};

long int hash_rabin_karp(std::string s1, int begin, int end);

bool already_added(std::vector<Song*>& s, Song*& t);
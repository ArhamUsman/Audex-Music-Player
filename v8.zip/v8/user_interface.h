#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <unordered_map>
#include <algorithm>
#include "pfd.h"
#include "data_structures.h"

namespace fs = std::filesystem;


// Main Application
class MusicPlayer {
private:
    sf::RenderWindow window;
    tgui::Gui gui;
    MusicLibrary library;
    MusicLibrary temp_library;
    AVLTree avlTree;
    std::unordered_map<std::string, DLLNode*> hashTable; // 3. Hash table for search
    Stack playbackHistory; // 6. Stack for history
    Queue playQueue; // 7. Queue for play next

    int currentSongIndex;
    bool isPlaying;
    float currentTime;
    tgui::Slider::Ptr progressSlider;
    tgui::Label::Ptr timeLabel;
    tgui::Button::Ptr playPauseBtn;
    tgui::Label::Ptr currentSongTitle;
    tgui::Label::Ptr currentSongArtist;
    tgui::Panel::Ptr currentArtwork;
    tgui::ListBox::Ptr songListBox;
    tgui::EditBox::Ptr searchBox;
    sf::Clock clock;
    sf::Music music;
    tgui::CheckBox::Ptr queueCheck = tgui::CheckBox::create();
    std::vector<tgui::Texture> m_animTextures; // Stores the 6 images
    tgui::Picture::Ptr m_animPicture;          // The widget that displays them
    sf::Clock m_clock;
    int m_currentFrame = 0;
    sf::Time m_animTimer;

public:
    MusicPlayer();

    void updateAnimation(sf::Time dt);
    
    void scanFolderRecursive(const std::string& path);

    void searchSong(const std::string& query);

    void quickSort(std::vector<Song*>& songs, size_t low, size_t high, bool (*compare)(Song*, Song*));
    
    void sortLibrary(const std::string& sortBy);

    void update_ds(std::vector<Song*> songs);

    void setupUI();

    void createSidebar();

    void update_queue(Song*& s);

    tgui::Button::Ptr createNavButton(const std::string& text, float y);

    void createMainContent();

    void createPlayerBar();

    void importFolder();

    void updateSongList(const std::vector<Song*>& songs);

    void select_song_by_index(int index);

    void playSongByPointer(Song* song);
    
    void removeCurrentFromQueue();

    void togglePlayPause();

    void nextSong();

    void previousSong();

    void addCurrentToQueue();

    void showHistory();

    void showQueue();

    void run();
};

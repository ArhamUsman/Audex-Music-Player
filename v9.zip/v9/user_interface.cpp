#include "user_interface.h"

MusicPlayer::MusicPlayer() : window(sf::VideoMode({ 750, 565 }), "Audex"), gui(window),
currentSongIndex(0), isPlaying(false), currentTime(0) {
    window.setFramerateLimit(60);
    setupUI();
    importFolder();
    auto songs = library.getAllSongs();
    if (songs.empty()) {
        std::string msg = "Directory doesn't contain any Song:\nEXITING";
        pfd::message("Error Report", msg, pfd::choice::ok).result();
        exit(0);
    }
    playSongByPointer(songs[0]);
    togglePlayPause();
}

void MusicPlayer::setupUI() {
    auto mainPanel = tgui::Panel::create();
    mainPanel->setSize("100%", "100%");
    mainPanel->getRenderer()->setBackgroundColor(tgui::Color(18, 18, 18));
    gui.add(mainPanel);

    createSidebar();
    createMainContent();
    createPlayerBar();
}

void MusicPlayer::importFolder() {
    auto selection = pfd::select_folder("Select Music Folder").result();
    if (!selection.empty()) {
        scanFolderRecursive(selection);
        updateSongList(temp_library.getAllSongs());
    }
}

void MusicPlayer::playSongByPointer(Song* song) {
    if (temp_library.getCurrent()) {
        playbackHistory.push(temp_library.getCurrent()->song);
    }
    int index = 0;
    DLLNode* temp = temp_library.getHead();
    while (temp && temp->song->title != song->title) {
        index++;
        temp = temp->next;
    }

    if (temp) {
        if (temp->song->title != temp_library.getCurrent()->song->title) {
            loop = false;
            loopCheck->setChecked(false);
        }
        temp_library.setCurrent(temp);
        update_queue(temp->song);
        currentSongTitle->setText(song->title);
        currentSongArtist->setText(song->artist);
        currentSongAlbum->setText(song->album);
        if (music.openFromFile(song->filePath)) {
            music.play();
            isPlaying = true;
            playPauseBtn->setText(u8"\u23F8");
            progressSlider->setMaximum(music.getDuration().asSeconds());
        }
        select_song_by_index(index);
    }
}

void MusicPlayer::togglePlayPause() {
    if (isPlaying) {
        music.pause();
        isPlaying = false;
        playPauseBtn->setText(u8"\u25B6");
    }
    else {
        music.play();
        isPlaying = true;
        playPauseBtn->setText(u8"\u23F8");
    }
}

void MusicPlayer::createSidebar() {
    auto sidebar = tgui::Panel::create();
    sidebar->setSize(240, "100%");
    sidebar->setPosition(0, 0);
    sidebar->getRenderer()->setBackgroundColor(tgui::Color(0, 0, 0));
    gui.add(sidebar);

    auto logo = tgui::Label::create("Audex");
    logo->setPosition(70, 21);
    logo->setTextSize(40);
    logo->getRenderer()->setTextColor(tgui::Color(135, 206, 250));
    logo->getRenderer()->setFont(headingFont);
    sidebar->add(logo);

    // Search bar
    searchBox = tgui::EditBox::create();
    searchBox->setSize(220, 35);
    searchBox->setPosition(10, 100);
    searchBox->setDefaultText("Search...");
    searchBox->setTextSize(16);
    searchBox->getRenderer()->setTextColor(tgui::Color::White);
    searchBox->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    searchBox->getRenderer()->setBorderColor(tgui::Color(70, 70, 70));
    searchBox->getRenderer()->setDefaultTextColor(tgui::Color(160, 160, 160));
    searchBox->getRenderer()->setBackgroundColorHover(tgui::Color(70, 70, 70));
    searchBox->onTextChange([this](const tgui::String& text) {
        searchSong(text.toStdString());
        });
    sidebar->add(searchBox);

    // Sort dropdown
    auto sortDropdown = tgui::ComboBox::create();
    sortDropdown->setPosition(10, 350);
    sortDropdown->setSize(220, 35);
    sortDropdown->addItem("Sort by Title");
    sortDropdown->addItem("Sort by Artist (AVL)");
    sortDropdown->addItem("Sort by Album");
    sortDropdown->setSelectedItem("Sort by Title");
    sortDropdown->onItemSelect([this](const tgui::String& item) {
        if (item == "Sort by Title") sortLibrary(0);
        else if (item == "Sort by Artist (AVL)") sortLibrary(1);
        else if (item == "Sort by Album") sortLibrary(2);
        });
    sidebar->add(sortDropdown);

    auto libraryBtn = createNavButton("Import Folder", 400);
    libraryBtn->onPress([this]() { importFolder(); });
    sidebar->add(libraryBtn);

    auto historyBtn = createNavButton("History (Stack)", 450);
    historyBtn->onPress([this]() { showHistory(); });
    sidebar->add(historyBtn);

    auto queueBtn = createNavButton("Play Queue", 500);
    queueBtn->onPress([this]() { showQueue(); });
    sidebar->add(queueBtn);

    // Song list
    songListBox = tgui::ListBox::create();
    songListBox->setPosition(10, 150);
    songListBox->setSize(218, 180);
    songListBox->setItemHeight(50);
    songListBox->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    songListBox->getRenderer()->setTextColor(tgui::Color::White);
    songListBox->onItemSelect([this](int index) {
        if (index >= 0) {
            auto songs = temp_library.getAllSongs();
            if (index < songs.size()) {
                playSongByPointer(songs[index]);
            }
        }
        });
    sidebar->add(songListBox);
}

void MusicPlayer::createMainContent() {
    auto mainContent = tgui::Panel::create();
    mainContent->setSize(510, 460);
    mainContent->setPosition(240, 0);
    mainContent->getRenderer()->setBackgroundColor(tgui::Color(10, 10, 10));
    gui.add(mainContent);

    auto header = tgui::Label::create("NOW PLAYING");
    header->setPosition(140, 30);
    header->setTextSize(32);
    header->getRenderer()->setTextColor(tgui::Color::White);
    mainContent->add(header);

    // Current song card
    currentArtwork = tgui::Panel::create();
    currentArtwork->setSize(250, 300);
    currentArtwork->setPosition(134, 85);
    currentArtwork->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    currentArtwork->getRenderer()->setRoundedBorderRadius(5);
    mainContent->add(currentArtwork);

    auto artwork = tgui::Panel::create();
    artwork->setSize(230, 200);
    artwork->setPosition(10, 10);
    artwork->getRenderer()->setBackgroundColor(tgui::Color(100, 100, 100));
    artwork->getRenderer()->setRoundedBorderRadius(5);
    m_animTextures.clear();
    for (int i = 1; i <= 6; i++) {
        m_animTextures.push_back(tgui::Texture("assets/frame" + std::to_string(i) + ".jpg"));
    }
    if (!m_animTextures.empty()) {
        m_animPicture = tgui::Picture::create(m_animTextures[0]);
        m_animPicture->setSize("100%", "100%");
        artwork->add(m_animPicture);
    }
    currentArtwork->add(artwork);

    currentSongTitle = tgui::Label::create("No Song");
    currentSongTitle->setPosition(10, 225);
    currentSongTitle->setTextSize(14);
    currentSongTitle->getRenderer()->setTextColor(tgui::Color::White);
    currentArtwork->add(currentSongTitle);

    currentSongArtist = tgui::Label::create("Select a song");
    currentSongArtist->setPosition(10, 250);
    currentSongArtist->setTextSize(12);
    currentSongArtist->getRenderer()->setTextColor(tgui::Color(160, 160, 160));
    currentArtwork->add(currentSongArtist);

    currentSongAlbum = tgui::Label::create("Select a song");
    currentSongAlbum->setPosition(10, 273);
    currentSongAlbum->setTextSize(12);
    currentSongAlbum->getRenderer()->setTextColor(tgui::Color(160, 160, 160));
    currentArtwork->add(currentSongAlbum);

    queueCheck->setPosition(30, 420);
    queueCheck->setSize(25, 25);
    queueCheck->setText("Add to Queue");
    queueCheck->setTextSize(16);
    queueCheck->getRenderer()->setBackgroundColor(tgui::Color::Transparent);
    queueCheck->getRenderer()->setBorderColor(tgui::Color::White);
    queueCheck->getRenderer()->setTextColor(tgui::Color::White);
    queueCheck->getRenderer()->setBackgroundColorChecked(tgui::Color(30, 144, 255));
    queueCheck->getRenderer()->setBorderColorChecked(tgui::Color(30, 144, 255));
    queueCheck->getRenderer()->setCheckColor(tgui::Color::White);
    queueCheck->getRenderer()->setBorderColorHover(tgui::Color::White);
    queueCheck->getRenderer()->setTextColorHover(tgui::Color(135, 206, 250));
    queueCheck->onChange([this](bool checked) {
        if (checked) addCurrentToQueue();
        else removeCurrentFromQueue();
        });
    mainContent->add(queueCheck);

    loopCheck->setPosition(410, 420);
    loopCheck->setSize(25, 25);
    loopCheck->setText("Loop");
    loopCheck->setTextSize(16);
    loopCheck->getRenderer()->setBackgroundColor(tgui::Color::Transparent);
    loopCheck->getRenderer()->setBorderColor(tgui::Color::White);
    loopCheck->getRenderer()->setTextColor(tgui::Color::White);
    loopCheck->getRenderer()->setBackgroundColorChecked(tgui::Color(30, 144, 255));
    loopCheck->getRenderer()->setBorderColorChecked(tgui::Color(30, 144, 255));
    loopCheck->getRenderer()->setCheckColor(tgui::Color::White);
    loopCheck->getRenderer()->setBorderColorHover(tgui::Color::White);
    loopCheck->getRenderer()->setTextColorHover(tgui::Color(135, 206, 250));
    loopCheck->onChange([this](bool checked) {
        if (checked) loop=true;
        else loop=false;
        });
    mainContent->add(loopCheck);
}

void MusicPlayer::createPlayerBar() {
    auto playerBar = tgui::Panel::create();
    playerBar->setSize(510, 100);
    playerBar->setPosition(240, 460);
    playerBar->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    gui.add(playerBar);

    auto prevBtn = tgui::Button::create(u8"\u23EE");
    prevBtn->setSize(50, 40);
    prevBtn->setPosition(150, 15);
    prevBtn->setTextSize(25);
    prevBtn->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    prevBtn->getRenderer()->setBackgroundColorHover(tgui::Color(60, 60, 60));
    prevBtn->getRenderer()->setTextColor(tgui::Color::White);
    prevBtn->getRenderer()->setFont(symbolFont);
    prevBtn->onPress([this]() { previousSong(); });
    playerBar->add(prevBtn);

    playPauseBtn = tgui::Button::create(u8"\u25B6");
    playPauseBtn->setSize(60, 50);
    playPauseBtn->setPosition(230, 10);
    playPauseBtn->setTextSize(30);
    playPauseBtn->getRenderer()->setBackgroundColor(tgui::Color::White);
    playPauseBtn->getRenderer()->setTextColor(tgui::Color::Black);
    playPauseBtn->getRenderer()->setRoundedBorderRadius(5);
    playPauseBtn->getRenderer()->setFont(symbolFont);
    playPauseBtn->onPress([this]() { togglePlayPause(); });
    playerBar->add(playPauseBtn);

    auto nextBtn = tgui::Button::create(u8"\u23ED");
    nextBtn->setSize(50, 40);
    nextBtn->setPosition(320, 15);
    nextBtn->setTextSize(25);
    nextBtn->getRenderer()->setBackgroundColor(tgui::Color(40, 40, 40));
    nextBtn->getRenderer()->setBackgroundColorHover(tgui::Color(60, 60, 60));
    nextBtn->getRenderer()->setTextColor(tgui::Color::White);
    nextBtn->getRenderer()->setFont(symbolFont);
    nextBtn->onPress([this]() { nextSong(); });
    playerBar->add(nextBtn);

    progressSlider = tgui::Slider::create();
    progressSlider->setSize(400, 5);
    progressSlider->setPosition(50, 70);
    progressSlider->setMinimum(0);
    progressSlider->setMaximum(100);
    progressSlider->setValue(0);

    progressSlider->onValueChange([this](float newValue) {
        float currentActualTime = music.getPlayingOffset().asSeconds();
        float diff = std::abs(newValue - currentActualTime);
        if (diff > 0.5f) {
            music.setPlayingOffset(sf::seconds(newValue));
        }
        });

    playerBar->add(progressSlider);

    timeLabel = tgui::Label::create("0:00 / 0:00");
    timeLabel->setPosition(230, 83);
    timeLabel->setTextSize(11);
    timeLabel->getRenderer()->setTextColor(tgui::Color(160, 160, 160));
    playerBar->add(timeLabel);
}

void MusicPlayer::scanFolderRecursive(const std::string& path) {
    try {
        auto options = fs::directory_options::skip_permission_denied;
        for (const auto& entry : fs::recursive_directory_iterator(path, options)) {
            try {
                if (entry.is_regular_file()) {

                    std::string ext = entry.path().extension().string();
                    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);

                    if (ext == ".mp3") {
                        Song* newSong = new Song(entry.path().string());

                        library.addSong(newSong);
                        temp_library.addSong(newSong); 
                        avlTree.insert(newSong);       
                        hashTable.insert(newSong);     
                    }
                }
            }
            catch (const std::exception& innerEx) {
                std::cerr << "Skipping bad file: " << innerEx.what() << std::endl;
            }
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Critical error scanning folder: " << e.what() << std::endl;
        pfd::message("Error", "Could not access the selected folder.", pfd::choice::ok).result();
    }
}

void MusicPlayer::updateSongList(const std::vector<Song*>& songs) {
    songListBox->removeAllItems();
    for (const auto& song : songs) {
        songListBox->addItem(song->title + " - " + song->artist);
    }
}

void MusicPlayer::update_queue(Song*& s) {
    queueCheck->setChecked(playQueue.is_in_queue(s));
}

void MusicPlayer::select_song_by_index(int index) {
    if (index < 0 || index >= songListBox->getItemCount()) return;
    songListBox->setSelectedItemByIndex(index);
}

void MusicPlayer::searchSong(const std::string& query) {
    std::string lowerQuery = query;
    std::transform(lowerQuery.begin(), lowerQuery.end(), lowerQuery.begin(), ::tolower);

    songListBox->removeAllItems();

    std::vector<Song*> songs;

    if (lowerQuery == "") {
        temp_library.clear();
        library.reset();
        Song* temp = library.getHead()->song, * t = temp;     //restore from duplicate
        while (t != nullptr) {
            temp_library.addSong(t);
            songs.push_back(t);
            t = library.next();
            if (t->title == temp->title) break;
        }
        updateSongList(songs);
        playQueue.clear();
        return;
    }

    temp_library.clear();

    //search by title
    
    std::vector<Song*> t = hashTable.search(lowerQuery);
    for (int i = 0; i < t.size(); i++) {
        if (already_added(songs, t[i])) continue;
        temp_library.addSong(t[i]);
        songs.push_back(t[i]);
    }
    
    //search by artist
    std::vector<Song*> s = avlTree.search(lowerQuery);
    for (int i = 0; i < s.size(); i++) {
        if (already_added(songs, s[i])) continue;
        temp_library.addSong(s[i]);
        songs.push_back(s[i]);
    }

    updateSongList(songs);
    playQueue.clear();
    if (songs.empty()) return;
    playSongByPointer(temp_library.getHead()->song);
    togglePlayPause();
}

void MusicPlayer::sortLibrary(int sortBy) {
    loop = false;
    loopCheck->setChecked(false);
    std::vector<Song*> songs;
    if (sortBy == 1) {
        songs = avlTree.getSortedByArtist();
        temp_library.update(songs);
    }
    else songs = temp_library.sort(sortBy);
    if (songs.empty()) return;
    updateSongList(songs);
    playQueue.clear();
    playSongByPointer(temp_library.getHead()->song);
    togglePlayPause();
}

tgui::Button::Ptr MusicPlayer::createNavButton(const std::string& text, float y) {
    auto btn = tgui::Button::create(text);
    btn->setPosition(10, y);
    btn->setSize(220, 40);
    btn->setTextSize(14);
    btn->getRenderer()->setBackgroundColor(tgui::Color(30, 30, 30));
    btn->getRenderer()->setBackgroundColorHover(tgui::Color(50, 50, 50));
    btn->getRenderer()->setTextColor(tgui::Color::White);
    btn->getRenderer()->setBorderColor(tgui::Color::Transparent);
    return btn;
}

void MusicPlayer::showHistory() {
    // Display history in a message box
    std::string msg = "Playback History:\n";
    Stack tempStack;
    tempStack = playbackHistory;
    int count = 0;
    while (!tempStack.empty() && count < 10) {
        msg += tempStack.top()->title + "\n";
        tempStack.pop();
        count++;
    }
    pfd::message("History", msg, pfd::choice::ok).result();
}

void MusicPlayer::showQueue() {
    std::string msg = "Play Queue:\n";
    Queue tempQueue;
    tempQueue = playQueue;
    while (!tempQueue.empty()) {
        msg += tempQueue.front()->title + "\n";
        tempQueue.pop();
    }
    pfd::message("Queue", msg.empty() ? "Queue is empty" : msg, pfd::choice::ok).result();
}

void MusicPlayer::addCurrentToQueue() {
    if (temp_library.getCurrent()) {
        playQueue.push(temp_library.getCurrent()->song);
    }
}

void MusicPlayer::removeCurrentFromQueue() {
    playQueue.remove(library.getCurrent()->song);
}

void MusicPlayer::previousSong() {
    if (loop) {
        playSongByPointer(temp_library.getCurrent()->song);
        return;
    }
    Song* prev = temp_library.previous();
    if (prev) {
        playSongByPointer(prev);
    }
}

void MusicPlayer::nextSong() {
    if (loop) {
        playSongByPointer(temp_library.getCurrent()->song);
    }
    else if (!playQueue.empty()) {
        Song* nextSong = playQueue.front();
        playQueue.pop();
        playSongByPointer(nextSong);
    }
    else {
        Song* next = temp_library.next();
        if (next) {
            playSongByPointer(next);
        }
    }
}

void MusicPlayer::updateAnimation(sf::Time dt) {
    if (m_animTextures.empty() || !m_animPicture) return;
    m_animTimer += dt;
    if (m_animTimer.asSeconds() >= 400.0f) {
        m_animTimer -= sf::seconds(400.0f);
        m_currentFrame++;
        if (m_currentFrame >= m_animTextures.size()) {
            m_currentFrame = 0;
        }
        m_animPicture->getRenderer()->setTexture(m_animTextures[m_currentFrame]);
    }
}

void MusicPlayer::run() {
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();
            gui.handleEvent(*event);
        }

        if (isPlaying && music.getStatus() == sf::SoundSource::Status::Playing) {
            progressSlider->setValue(music.getPlayingOffset().asSeconds());

            int current = static_cast<int>(music.getPlayingOffset().asSeconds());
            int total = static_cast<int>(music.getDuration().asSeconds());
            std::stringstream ss;
            ss << (current / 60) << ":" << std::setw(2) << std::setfill('0') << (current % 60)
                << " / " << (total / 60) << ":" << std::setw(2) << std::setfill('0') << (total % 60);
            timeLabel->setText(ss.str());

            sf::Time dt = m_clock.getElapsedTime(); 
            updateAnimation(dt);
        }

        if (music.getStatus() == sf::SoundSource::Status::Stopped && isPlaying) {
            nextSong();
        }

        window.clear();
        gui.draw();
        window.display();
    }
}
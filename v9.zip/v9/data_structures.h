#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <taglib/tag.h>
#include <taglib/fileref.h>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <filesystem>
#include <algorithm>
#include <cctype>
#include "pfd.h"

namespace fs = std::filesystem;

// Song structure
struct Song {
    std::string filePath;
    std::string title;
    std::string artist;
    std::string album;
    int duration;
    tgui::Color color;

    Song() = default;

    Song(const std::string& path);

    bool less(Song* other, int seq);

    bool greater(Song* other, int seq);
};

// Stack for playback history
class Stack {
    std::vector<Song*> arr; size_t topp;
public:
    Stack();

    bool empty();

    Song* top();

    void pop();

    void push(Song* a);

    void operator=(Stack& other);
};

// Queue for play next
class Queue {
    std::vector<Song*> arr; size_t tail;
public:
    Queue();

    bool empty();

    Song* front();

    void pop();

    void push(Song* a);

    bool is_in_queue(Song* other);

    void remove(Song* a);

    void clear();

    void operator=(Queue& other);
};

// Doubly Linked List Node
struct DLLNode {
    Song* song;
    DLLNode* prev;
    DLLNode* next;

    DLLNode(Song* s);
};

// Doubly Linked List for Music Library
class MusicLibrary {
private:
    DLLNode* head;
    DLLNode* tail;
    DLLNode* current;
    size_t size;

    int partition(std::vector<Song*>& arr, int i, int j, int& seq);

    void quickSort(std::vector<Song*>& arr, int l, int r, int& seq);

public:
    MusicLibrary();

    ~MusicLibrary();

    DLLNode* getHead();

    DLLNode* getCurrent();

    int getSize();

    std::vector<Song*> getAllSongs();

    void setCurrent(DLLNode* node);

    void update(std::vector<Song*>& arr);

    void reset();

    void addSong(Song* song);

    Song* previous();

    Song* next();

    std::vector<Song*> sort(int sortBy);

    void clear();
};

// AVL Tree Node for sorted view
struct AVLNode {
    Song* song;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(Song* s);
};

// AVL Tree
class AVLTree {
private:
    AVLNode* root;

    int height(AVLNode* node);

    int getBalance(AVLNode* node);

    AVLNode* leftRotate(AVLNode* x);

    AVLNode* rightRotate(AVLNode* y);

    AVLNode* insert(AVLNode* node, Song* song);

    void inorderTraversal(AVLNode* node, std::vector<Song*>& songs);

    void recursive_search(std::vector<Song*>& fina, std::string s, AVLNode* curr, bool matched); 
    
    void self_destroy(AVLNode*& r);

public:
    AVLTree();

    void insert(Song* song);

    std::vector<Song*> search(std::string s);

    std::vector<Song*> getSortedByArtist(); 
    
    void clear();
};

// Hash Table
class Hash_Table {
    std::vector<MusicLibrary> arr;

    int generate_key(std::string title);
public:
    Hash_Table();

    void insert(Song* song);
    
    std::vector<Song*> search(std::string s);
    
    void clear();
};

//Helper Functions
bool already_added(std::vector<Song*>& s, Song*& t);

long int hash_rabin_karp(std::string s1, int begin, int end);

bool rabin_karp(std::string title, std::string query);
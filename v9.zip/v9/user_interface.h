#pragma once

#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <algorithm>
#include "pfd.h"
#include "data_structures.h"

namespace fs = std::filesystem;


// Main Application
class MusicPlayer {
private:
    sf::RenderWindow window;
    tgui::Gui gui;
    MusicLibrary library;
    MusicLibrary temp_library;
    AVLTree avlTree;
    Hash_Table hashTable; // 3. Hash table for search
    Stack playbackHistory; // 6. Stack for history
    Queue playQueue; // 7. Queue for play next

    int currentSongIndex;
    bool isPlaying, loop=false;
    float currentTime;
    const tgui::Font symbolFont = "libraries/fonts/seguisym.ttf";
    const tgui::Font headingFont = "libraries/fonts/impact.ttf";
    tgui::Slider::Ptr progressSlider;
    tgui::Label::Ptr timeLabel;
    tgui::Button::Ptr playPauseBtn;
    tgui::Label::Ptr currentSongTitle;
    tgui::Label::Ptr currentSongArtist;
    tgui::Label::Ptr currentSongAlbum;
    tgui::Panel::Ptr currentArtwork;
    tgui::ListBox::Ptr songListBox;
    tgui::EditBox::Ptr searchBox;
    sf::Clock clock;
    sf::Music music;
    tgui::CheckBox::Ptr queueCheck = tgui::CheckBox::create();
    tgui::CheckBox::Ptr loopCheck = tgui::CheckBox::create();
    std::vector<tgui::Texture> m_animTextures; // Stores the 6 images
    tgui::Picture::Ptr m_animPicture;          // The widget that displays them
    sf::Clock m_clock;
    int m_currentFrame = 0;
    sf::Time m_animTimer;

public:
    MusicPlayer();

    void setupUI();

    void importFolder();

    void playSongByPointer(Song* song);

    void togglePlayPause();

    void createSidebar();

    void createMainContent();

    void createPlayerBar();

    void scanFolderRecursive(const std::string& path);

    void updateSongList(const std::vector<Song*>& songs);

    void update_queue(Song*& s);

    void select_song_by_index(int index);

    void searchSong(const std::string& query);

    void sortLibrary(int sortBy);

    tgui::Button::Ptr createNavButton(const std::string& text, float y);

    void showHistory();

    void showQueue();

    void addCurrentToQueue();

    void removeCurrentFromQueue();

    void previousSong();

    void nextSong();

    void updateAnimation(sf::Time dt);

    void run();
};
